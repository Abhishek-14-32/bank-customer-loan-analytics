# Bank Customer & Loan Analytics Dashboard

## Overview
An end-to-end Data Analytics portfolio project using **SQL and Power BI** to analyze customer profiles, loan applications, approvals, loan amounts, repayment behavior, and default risk.

> **Dataset note:** The included CSV files contain synthetic data created for portfolio/learning purposes. They do not represent a real bank or real customer records.

## Business Questions
- How many loan applications are approved, rejected, pending, or defaulted?
- Which loan types have the highest approved value?
- Which loan types have the highest default rate?
- How does credit score relate to customer risk?
- Which cities/regions contribute the most loan business?
- How does application volume change over time?
- What is the payment performance?

## Tools
- Power BI
- Power Query
- DAX
- SQL
- CSV

## Dashboard Pages
### 1. Executive Overview
- Total Customers
- Total Applications
- Approved Loans
- Total Approved Amount
- Defaulted Loans
- Approval Rate
- Default Rate
- Application trend
- Loan status distribution
- Loan type performance

### 2. Customer Analytics
- Age distribution
- Income segments
- Credit score distribution
- Employment type
- Customer location
- Risk categories

### 3. Loan & Risk Analytics
- Default rate by loan type
- Default amount by city
- Credit score vs loan amount
- Loan tenure analysis
- Payment performance

## Suggested Power BI Measures
- Total Customers
- Total Applications
- Approved Loans
- Rejected Loans
- Defaulted Loans
- Total Loan Amount
- Approved Loan Amount
- Approval Rate
- Default Rate
- Average Loan Amount

## Data Model
Customers -> Loans -> Payments
Branches can be related through City/Branch mapping as an additional dimension.

## How to Build
1. Import the four CSV files into Power BI.
2. Clean data in Power Query.
3. Create relationships and a star-schema-style model.
4. Create DAX measures.
5. Build the three dashboard pages.
6. Export dashboard screenshots to `Screenshots/`.
7. Save the `.pbix` file in `PowerBI/` if its size is suitable for your GitHub workflow.

## Portfolio Disclaimer
This project is for educational and portfolio purposes. Risk thresholds and financial conclusions are illustrative, not banking or lending advice.
